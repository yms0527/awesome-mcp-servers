/**
 *
 */
module.exports = {
    extends: ['alloy', 'alloy/typescript'],
    rules: {
        semi: ['error'],
        complexity: ['error', { max: 40 }],
        'no-useless-constructor': 'off',
        '@typescript-eslint/explicit-member-accessibility': 'off',
        '@typescript-eslint/explicit-function-return-type': 'off',
        '@typescript-eslint/interface-name-prefix': 'off',
        '@typescript-eslint/no-useless-constructor': 'off',
        '@typescript-eslint/no-parameter-properties': 'off'
    },
    env: {
        node: true,
        jest: true
    },
    globals: {
        NodeJS: true
    },
    overrides: [
        {
            files: ['*.js'],
            rules: {
                '@typescript-eslint/no-var-requires': 'off'
            }
        }
    ]
};
