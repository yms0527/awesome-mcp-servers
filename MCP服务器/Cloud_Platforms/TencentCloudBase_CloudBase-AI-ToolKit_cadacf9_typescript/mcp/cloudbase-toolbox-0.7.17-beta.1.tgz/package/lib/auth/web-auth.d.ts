import { Credential } from '../types';
export declare const CLI_AUTH_BASE_URL = "https://tcb.cloud.tencent.com/dev";
export declare function getAuthTokenFromWeb(options?: {
    getAuthUrl?: (rawUrl: string) => string;
    noBrowser?: boolean;
    callbackTimeout?: number;
}): Promise<Credential>;
