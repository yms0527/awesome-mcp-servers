import { LocalStore } from '../localstore';
import { CloudBaseError } from '../error';
import { Credential, WebAuthCredential, RequestConfig } from '../types';
export declare const authStore: LocalStore<{
    _: string;
    credential: Partial<Credential> & Partial<WebAuthCredential>;
}>;
export declare enum ENV_NAME {
    ENV_SECRETID = "TENCENTCLOUD_SECRETID",
    ENV_SECRETKEY = "TENCENTCLOUD_SECRETKEY",
    ENV_SESSIONTOKEN = "TENCENTCLOUD_SESSIONTOKEN",
    ENV_TCB_ENV_ID = "TENCENTCLOUD_TCB_ENVID",
    ENV_RUNENV = "TENCENTCLOUD_RUNENV",
    ENV_RUNENV_SCF = "TENCENTCLOUD_RUNENV=SCF"
}
export declare function getCredentialData(): Promise<Credential>;
export declare function refreshTmpToken(metaData: Credential & {
    isLogout?: boolean;
}): Promise<WebAuthCredential>;
export declare const isCamRefused: (e: CloudBaseError) => boolean;
export declare function checkAndGetCredential(options?: RequestConfig): Promise<Credential>;
export declare function getCredentialWithoutCheck(): Promise<Credential>;
