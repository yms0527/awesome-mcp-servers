import { Credential } from "../types";
export interface DeviceFlowOptions {
    client_id?: string;
    onDeviceCode?: (data: {
        user_code: string;
        verification_uri?: string;
        device_code: string;
        expires_in: number;
    }) => void;
}
export declare function getAuthTokenByDeviceFlow(options?: DeviceFlowOptions): Promise<Credential>;
