import { Credential, WebAuthCredential, RequestConfig } from '../types';
export declare function checkAuth(credential: Credential, options?: RequestConfig): Promise<any>;
export declare function resolveCredential(data: Partial<Credential> & Partial<WebAuthCredential>): Credential;
export declare function resolveWebCredential(credential: Credential): WebAuthCredential;
