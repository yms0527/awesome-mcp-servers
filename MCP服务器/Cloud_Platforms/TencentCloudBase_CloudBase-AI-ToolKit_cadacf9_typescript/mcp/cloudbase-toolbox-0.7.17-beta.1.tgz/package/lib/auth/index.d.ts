import { DeviceFlowOptions } from './oauth';
import { Credential, RequestConfig } from '../types';
export * from './common';
export * from './credential';
export * from './web-auth';
export * from './oauth';
export interface AuthSupervisorOptions {
    /**
     * 是否在内存中缓存 credential 信息
     */
    cache?: boolean;
    /**
     * 网络请求代理配置
     */
    proxy?: string;
    /**
     * 请求超时时间
     */
    timeout?: number;
    /**
     * 登录失败时是否抛出错误，默认返回 null
     */
    throwError?: boolean;
}
export type AuthFlowMode = 'web' | 'device';
export interface WebAuthOptions {
    /**
     * 请在初始化实例时指定
     * @deprecated
     */
    throwError?: boolean;
    /**
     * 授权方式
     * - 'web': 使用网页回调授权
     * - 'device': 使用 Device Flow 授权
     * @default 'device'
     */
    mode?: AuthFlowMode;
    getAuthUrl?: (rawUrl: string) => string;
    noBrowser?: boolean;
    callbackTimeout?: number;
    /** Device Flow 的客户端 ID */
    client_id?: string;
    /** Device Flow 回调，获取设备码后通知调用方 */
    onDeviceCode?: DeviceFlowOptions['onDeviceCode'];
}
export interface LoginByApiSecretOptions {
    /**
     * 强制更新 Credential，忽略缓存
     * @default false
     */
    forceUpdate?: boolean;
    /**
     * 是否将 credential 存储为 WebCredential 格式
     * @default false
     */
    storeAsWebCredential?: boolean;
    /**
     * 额外的 Credential 字段
     */
    additionalCredentialFields?: Omit<Credential, 'secretId' | 'secretKey' | 'token'>;
}
export declare class AuthSupervisor {
    static instance: AuthSupervisor;
    /**
     * 单例模式，全局缓存
     * @param options
     */
    static getInstance(options?: AuthSupervisorOptions): AuthSupervisor;
    cacheCredential: Credential;
    needCache: boolean;
    cacheExpiredTime: number;
    requestConfig: RequestConfig;
    throwError: boolean;
    constructor(options?: AuthSupervisorOptions);
    /**
     * 获取登录状态信息
     */
    getLoginState(): Promise<Credential>;
    /**
     * 通过网页授权登录
     * @returns credential
     */
    loginByWebAuth(options?: WebAuthOptions): Promise<Credential>;
    /**
     * 通过 API Secret 登录，支持临时秘钥
     * @param secretId
     * @param secretKey
     * @param token
     * @param opts 选项配置，包括强制更新和额外的 Credential 字段
     * @returns credential
     */
    loginByApiSecret(secretId?: string, secretKey?: string, token?: string, opts?: LoginByApiSecretOptions): Promise<Credential>;
    logout(): Promise<void>;
    private isCacheExpire;
}
/**
 * @deprecated Use `AuthSupervisorOptions` instead. This type has a spelling error and will be removed in a future version.
*/
export interface AuthSupevisorOptions extends AuthSupervisorOptions {
}
/**
 * @deprecated Use `AuthSupervisor` instead. This class has a spelling error and will be removed in a future version.
 */
export declare class AuthSupevisor extends AuthSupervisor {
    static instance: AuthSupevisor;
    /**
     * @deprecated Use `AuthSupervisor.getInstance` instead
     */
    static getInstance(options?: AuthSupevisorOptions): AuthSupevisor;
    /**
     * @deprecated Use `AuthSupervisor` constructor instead
     */
    constructor(options?: AuthSupevisorOptions);
}
