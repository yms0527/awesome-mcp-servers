export interface IQuery {
    [key: string]: string;
}
export type GetUrlFn = (port: number) => string;
export type CheckFn = (query: IQuery) => Promise<void>;
export interface GetDataFromWebOptions {
    noBrowser?: boolean;
    callbackTimeout?: number;
}
export declare function isTruthyFlag(value?: string): boolean;
export declare function openUrl(url: string): Promise<boolean>;
export declare function getDataFromWeb<T extends IQuery>(getUrl: GetUrlFn, type: 'login' | 'getData', options?: GetDataFromWebOptions): Promise<T>;
