export declare function getMacAddress(): Promise<string>;
