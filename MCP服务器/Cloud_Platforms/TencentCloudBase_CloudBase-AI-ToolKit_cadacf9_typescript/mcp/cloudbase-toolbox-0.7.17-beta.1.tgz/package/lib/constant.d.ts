export declare const REQUEST_TIMEOUT = 15000;
