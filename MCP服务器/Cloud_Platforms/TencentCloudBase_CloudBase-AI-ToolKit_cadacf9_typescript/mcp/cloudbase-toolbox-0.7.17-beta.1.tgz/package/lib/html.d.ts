export declare const html: {
    getDataFail: string;
    getDataSuccess: string;
    loginFail: string;
    loginSuccess: string;
};
export declare function getHTML(type: string): any;
