export type PromiseFn<T> = () => Promise<T>;
export type CallbackFn = (e: Error, ret: any) => void;
export interface IMergeOptions {
    maxAge?: number;
    timeout?: number;
}
/**
 * 异步任务合并
 */
export declare class AsyncMerge {
    static instance: AsyncMerge;
    static merge<T>(fn: PromiseFn<T>, taskId: string | number, options?: IMergeOptions): Promise<T>;
    private tasks;
    merge<T>(fn: PromiseFn<T>, taskId: string | number, options?: IMergeOptions): Promise<T>;
    runTask<T>(fn: PromiseFn<T>, taskId: string | number, taskOptions: IMergeOptions, cb: CallbackFn): void;
}
