import YAML from 'yaml';
export declare const yamlParse: (doc: string) => any;
export declare const yamlStringify: (object: any) => string;
export declare const yaml: typeof YAML;
