declare class Loading {
    private spinner;
    constructor();
    set text(text: string);
    start(text: string): void;
    stop(): void;
    succeed(text: string): void;
    fail(text: string): void;
}
export declare const loadingFactory: () => Loading;
type Task<T> = (flush: (text: string) => void, ...args: any[]) => Promise<T>;
export interface ILoadingOptions {
    startTip?: string;
    successTip?: string;
    failTip?: string;
}
/**
 * 执行异步任务，显示 loading 动画
 * @param task
 * @param options
 */
export declare const execWithLoading: <T>(task: Task<T>, options?: ILoadingOptions) => Promise<T>;
export {};
