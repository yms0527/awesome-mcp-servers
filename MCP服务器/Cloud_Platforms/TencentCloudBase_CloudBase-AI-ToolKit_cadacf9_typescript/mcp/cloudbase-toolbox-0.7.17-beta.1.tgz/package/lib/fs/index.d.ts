/**
 * 检查路径是否可以访问（读、写）
 * @param dest 目标路径
 * @param throwError 无权限时是否抛出异常
 */
export declare function checkFullAccess(dest: string, throwError?: boolean): boolean;
/**
 * 检查路径是否可以读
 * @param dest 目标路径
 * @param throwError 无权限时是否抛出异常
 */
export declare function checkWritable(dest: string, throwError?: boolean): boolean;
/**
 * 检查路径是否可以写
 * @param dest 目标路径
 * @param throwError 无权限或路径不存在时是否抛出异常
 */
export declare function checkReadable(dest: string, throwError?: boolean): boolean;
/**
 * 检查指定路径是否为文件夹
 * @param dest 目标路径
 */
export declare function isDirectorySync(dest: string): boolean;
/**
 * 检查指定路径是否为文件夹，异步
 * @param dest 目标路径
 */
export declare function isDirectoryAsync(dest: string): Promise<boolean>;
export type SizeUnit = 'KB' | 'MB' | 'GB' | 'TB';
/**
 * 格式化文件大小，保留两位小数
 * @param size 原数据，单位 Byte
 * @param unit 目标单位，支持 KB、MB、GB、TB
 * @param fixed 保留小数位数，默认 2 位
 */
export declare function formateFileSize(size: number | string, unit: SizeUnit, fixed: number): string;
export declare function mkdirSync(dest: string): void;
export declare function mkdirAsync(dest: string): Promise<void>;
export declare const slash: (input: string) => string;
export declare function delSync(patterns: string | readonly string[]): void;
