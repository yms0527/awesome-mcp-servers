export interface Credential {
    secretId: string;
    secretKey: string;
    token?: string;
    accessTokenExpired?: number;
    expired?: number;
    authTime?: number;
    refreshToken?: string;
    uin?: string;
    hash?: string;
    envId?: string;
}
export interface WebAuthCredential {
    tmpSecretId: string;
    tmpSecretKey: string;
    tmpToken: string;
    tmpExpired: number;
    expired: number;
    authTime: number;
    refreshToken: string;
    uin?: string;
    hash?: string;
    envId?: string;
}
export interface RequestConfig {
    proxy?: string;
    timeout?: number;
}
export interface IFunctionVPC {
    subnetId: string;
    vpcId: string;
}
export interface ICloudFunctionConfig {
    timeout?: number;
    envVariables?: Record<string, string | number | boolean>;
    runtime?: string;
    vpc?: IFunctionVPC;
    installDependency?: boolean;
    l5?: boolean;
}
export interface ICloudFunctionTrigger {
    name: string;
    type: string;
    config: string;
}
export interface ICloudFunction {
    name: string;
    config?: ICloudFunctionConfig;
    triggers?: ICloudFunctionTrigger[];
    params?: Record<string, string>;
    handler?: string;
    ignore?: string | string[];
    timeout?: number;
    envVariables?: Record<string, string | number | boolean>;
    runtime?: string;
    vpc?: IFunctionVPC;
    l5?: boolean;
    installDependency?: boolean;
    isWaitInstall?: boolean;
}
export interface ICloudBaseConfig {
    envId: string;
    region?: string;
    version?: string;
    functionRoot?: string;
    functionDefaultConfig?: ICloudFunction;
    functions?: ICloudFunction[];
}
