export interface ICacheOptions {
    nil: boolean;
}
/**
 * 缓存模块
 * 1. 内存缓存
 * 2. TODO: 本地缓存
 */
export declare class Cache {
    static NIL: symbol;
    private store;
    private nil;
    constructor(nil?: boolean);
    /**
     * 设置缓存
     * @param key 缓存 key
     * @param value 缓存值
     * @param maxAge 缓存保持时间，单位 ms
     */
    set(key: string | number, value: any, maxAge?: number): void;
    /**
     * 获取缓存结果
     * @param key 缓存 key
     */
    get<T = any>(key: any): T | null | Symbol;
}
export declare const memoryCache: Cache;
export declare const nilCache: Cache;
