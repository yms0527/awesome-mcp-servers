/**
 * 解析从云端下发的配置
 */
export declare function getCloudConfig(): void;
