import { ICloudBaseConfig } from '../types';
/**
 * 获取当前目录下的 cloudbase 配置
 */
export declare const getCloudBaseConfig: (configPath?: string) => Promise<ICloudBaseConfig>;
/**
 * 从命令行参数和配置文件中读取 region
 */
export declare const getRegion: (noDefault?: boolean) => Promise<string>;
