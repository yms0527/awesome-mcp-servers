import { CosmiconfigResult } from './explorer/types';
export interface LoadOptions {
    searchFrom?: string;
    configPath?: string;
    moduleName?: string;
}
/**
 * 搜索指定配置文件，返回包含路径等信息
 */
export declare function searchConfig(dest: string, moduleName?: string): Promise<CosmiconfigResult>;
/**
 * 搜索或指定配置文件路径
 * 加载配置文件内容
 */
export declare function loadConfig(options?: LoadOptions): Promise<any>;
