import { Loader, LoaderSync, Options, OptionsSync } from './index';
export type Config = any;
export type CosmiconfigResult = {
    config: Config;
    filepath: string;
    isEmpty?: boolean;
} | null;
export interface ExplorerOptions extends Required<Options> {
}
export interface ExplorerOptionsSync extends Required<OptionsSync> {
}
export type Cache = Map<string, CosmiconfigResult>;
export type LoadedFileContent = Config | null | undefined;
export interface Loaders {
    [key: string]: Loader;
}
export interface LoadersSync {
    [key: string]: LoaderSync;
}
