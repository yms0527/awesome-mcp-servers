import { Config, CosmiconfigResult, Loaders, LoadersSync } from './types';
type LoaderResult = Config | null;
export type Loader = ((filepath: string, content: string) => Promise<LoaderResult>) | LoaderSync;
export type LoaderSync = (filepath: string, content: string) => LoaderResult;
export type Transform = ((CosmiconfigResult: CosmiconfigResult) => Promise<CosmiconfigResult>) | TransformSync;
export type TransformSync = (CosmiconfigResult: CosmiconfigResult) => CosmiconfigResult;
interface OptionsBase {
    packageProp?: string;
    searchPlaces?: Array<string>;
    ignoreEmptySearchPlaces?: boolean;
    stopDir?: string;
    cache?: boolean;
}
export interface Options extends OptionsBase {
    loaders?: Loaders;
    transform?: Transform;
}
export interface OptionsSync extends OptionsBase {
    loaders?: LoadersSync;
    transform?: TransformSync;
}
declare function cosmiconfig(moduleName: string, options?: Options): {
    readonly search: any;
    readonly load: any;
    readonly clearLoadCache: any;
    readonly clearSearchCache: any;
    readonly clearCaches: any;
};
declare const defaultLoaders: Readonly<{
    readonly '.js': (filepath: any) => unknown;
    readonly '.json': (filepath: any, content: any) => any;
    readonly '.yaml': (filepath: any, content: any) => any;
    readonly '.yml': (filepath: any, content: any) => any;
    readonly noExt: (filepath: any, content: any) => any;
}>;
export { cosmiconfig, defaultLoaders };
