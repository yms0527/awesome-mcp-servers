import _dotenv from 'dotenv';
export declare const dotenv: typeof _dotenv;
export declare function loadEnvVariables(from?: string): {};
