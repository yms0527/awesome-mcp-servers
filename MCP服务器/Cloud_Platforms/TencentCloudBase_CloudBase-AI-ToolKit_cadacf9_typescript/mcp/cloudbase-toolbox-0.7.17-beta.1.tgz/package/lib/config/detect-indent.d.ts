export declare function detectIndent(string: any): {
    amount: number;
    type: any;
    indent: string;
};
