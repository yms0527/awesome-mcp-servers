import { ICloudBaseConfig } from '../types';
export interface ResolveOptions {
    searchFrom?: string;
    configPath?: string;
}
/**
 * 从配置文件中解析 cloudbase 配置
 */
export declare function resolveCloudBaseConfig(options: ResolveOptions): Promise<ICloudBaseConfig>;
/**
 * 从命令行和配置文件中获取 envId
 */
export declare function getEnvId(commandOptions: any): Promise<string>;
export interface ICloudBaseOptions {
    cwd?: string;
    cover?: boolean;
    configPath?: string;
}
export declare const renderConfig: (template: string, view: Record<string, any>) => any;
export declare class ConfigParser {
    static instance: ConfigParser;
    static get(key?: string, defaultValue?: any, options?: ICloudBaseOptions): Promise<any>;
    static update(key?: string, value?: any, options?: ICloudBaseOptions): Promise<void>;
    static parseRawConfig(rawConfig: Record<string, any>, cwd?: string): Promise<Record<string, any>>;
    private cwd;
    private configPath;
    private cover;
    constructor(options?: ICloudBaseOptions);
    options(options?: ICloudBaseOptions): this;
    get<T>(key?: string, defaultValue?: T): Promise<any>;
    update(key: string | Record<string, any>, value?: any, cover?: boolean): Promise<void>;
    getConfig(): Promise<Record<string, any>>;
    updateConfig(config: ICloudBaseConfig, cover?: boolean): Promise<void>;
}
