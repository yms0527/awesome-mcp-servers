declare const loaders: {
    loadJs: (filepath: any) => unknown;
    loadJson: (filepath: any, content: any) => any;
    loadYaml: (filepath: any, content: any) => any;
};
export { loaders };
