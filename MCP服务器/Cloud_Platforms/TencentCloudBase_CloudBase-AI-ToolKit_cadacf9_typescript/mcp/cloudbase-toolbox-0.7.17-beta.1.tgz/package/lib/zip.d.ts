/// <reference types="node" />
/// <reference types="node" />
import path from 'path';
export declare const decompress: any;
export declare const unzip: (zipFile: string, dest: string) => Promise<{
    data: Buffer;
    mode: Number;
    mtime: String;
    path: String;
    type: String;
}[]>;
/**
 * 解压流（使用临时 zip 包）
 * @param source 可读流
 * @param dest 解压目标文件夹
 * @param name 可选的临时 zip 包名
 */
export declare const unzipStream: (source: NodeJS.ReadableStream, dest: string, name?: string) => Promise<void>;
export declare function zipDir(dirPath: any, outputPath: any, ignore?: string | string[]): Promise<unknown>;
export declare function zipFiles(allFilesPath: string[], outputPath: string, ignore?: string | string[]): Promise<unknown>;
