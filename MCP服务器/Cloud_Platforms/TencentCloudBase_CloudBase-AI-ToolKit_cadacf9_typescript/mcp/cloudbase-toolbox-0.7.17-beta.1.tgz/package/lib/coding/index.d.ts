export declare function md5Encoding(str?: string): string;
