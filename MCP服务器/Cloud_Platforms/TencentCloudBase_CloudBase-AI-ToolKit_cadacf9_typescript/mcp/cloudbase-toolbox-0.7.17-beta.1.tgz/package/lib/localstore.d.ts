import low from 'lowdb';
export declare const cloudbaseConfigDir: string;
export declare function getAsyncDB(file: string): Promise<low.LowdbAsync<any>>;
export declare function getSyncDB(file: string): low.LowdbSync<any>;
export declare class LocalStore<Schema> {
    db: any;
    dbKey: string;
    defaults: Schema;
    constructor(defaults: Schema, dbKey?: string);
    getDB(): Promise<any>;
    get(key: keyof Schema): Promise<Schema[keyof Schema]>;
    set(key: keyof Schema, value: any): Promise<void>;
    push(key: keyof Schema, value: any): Promise<void>;
    delete(key: keyof Schema): Promise<void>;
}
