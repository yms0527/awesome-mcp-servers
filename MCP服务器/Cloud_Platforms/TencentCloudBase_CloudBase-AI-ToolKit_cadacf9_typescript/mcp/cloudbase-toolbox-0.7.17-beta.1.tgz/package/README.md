# Cloudbase Toolbox

云开发 Node Toolbox，工具合集，仅支持 Node 8.9+ 以上版本。

## V2 配置解析器

`@cloudbase/toolbox` **0.4.0**版本起，支持了新的 `cloudbaserc` 配置文件解析器。

当前配置文件无法满足现阶段的需求（重写配置文件，环境变量支持等），需要对配置文件进行重新设计。

新版配置文件 `version` 为 `2.0`，只支持 `JSON` 格式的配置文件，只有 `version` 声明为 `2.0` 的配置文件才支持模板变量。

### 使用方法

你可以在 `cloudbaserc.json` 配置文件中使用变量，从环境变量或其他数据源获取动态的数据。使用 `{{}}` 包围的值定义为变量，引用了数据源中的值。

```json
{
  "envId": "envId",
  "functionRoot": "./functions",
  "functions": [
      {
        "name": "{{variable}}"
      }
  ]
}
```

#### 数据源

CloudBase 定义多个数据源的命名空间，用于区分不同的数据源。你可以通过 `命名空间.变量名` 引用数据，如 `{{tcb.envId}}`

| 命名空间 | 变量名 | 含义                                  |
| -------- | ------ | ------------------------------------- |
| tcb      | envId  | 配置文件或通过命令行参数指定的环境 Id |
| util     | uid    | 24 位的随机字符串                     |
| env      | \*     | 从 `.env` 文件中加载的环境变量        |

#### env 环境变量

CloudBase 支持了 `env` 数据源，可以加载 [`.env`](https://github.com/motdotla/dotenv) 文件中的环境变量，并在使用 CLI 时，通过 `--mode` 参数指定不同的环境。

你可以替换你的项目根目录中的下列文件来指定环境变量：

```
.env                # 在所有的环境中被载入
.env.local          # 在所有的环境中被载入，可以加入 .gitignore 忽略
.env.[mode]         # 只在指定的模式中被载入
```

在加载 env 文件时，`.env` 和 `.env.local` 会被直接加载，当指定 `--mode [mode]` 时，会再加载 `.env.[mode]` 文件，并遵循如下的合并顺序：`.env.[mode] > .env.local > .env`，即 `.env.[mode]` 中的同名变量会覆盖 `.env.local` 和 `.env` 文件中的同名变量，以此类推。

如使用 `tcb framework:deploy --mode test` 命令时，会自动加载 `.env`，`.env.local` 以及 `.env.test` 等三个文件中的环境变量合并使用。


如 `.env`  文件中存在以下变量

```jsx
DB_HOST=localhost
DB_USER=root
DB_PASSWORD=s1mpl3
```

则可以在配置文件中使用

```json
{
  "envId": "xxx",
  "functionRoot": "./functions",
  "functions": [
      {
          "name": "test",
          "envVariables": {
              "PASSWORD": "{{env.DB_PASSWORD}}"
          }
      }
  ]
}
```

### 支持字段

#### version

当期配置文件版本，新版本从 `2.0` 开始，没有 `version` 字段的配置文件视为 `1.0` 版本。

#### envId

环境 Id

#### functionRoot

存放函数的根文件夹

#### functions

云函数配置

#### engine

保留字段

### 使用解析器

使用方法如下：

```js
import { ConfigParser } from '@cloudbase/toolbox'

const configParser = new ConfigParser({
    // 当前工作目录，搜索配置文件，.env 文件，默认为 process.cwd
    cwd: '',
    // 写本地配置时，遇到相同 key 时的处理策略
    cover: false,
    // 直接指定配置文件的路径，否则在 cwd 目录下尝试查找配置文件
    configPath: ''
})

// 获取全部配置文件
await configParser.get()
// 获取 envId
await configParser.get('envId')
// 获取第一个函数的超时时间，如果不存在，则返回默认值 3
await configParser.get('functions[0].timeout', 3)

await configParser.update('functions[0].timeout', 5)
```

直接使用静态方法

```js
import { ConfigParser } from '@cloudbase/toolbox'

// 获取全部配置文件
await ConfigParser.get()
// 获取 envId
await ConfigParser.get('envId')
// 获取第一个函数的超时时间，如果不存在，则返回默认值 3
await ConfigParser.get('functions[0].timeout', 3)
```
